from probability import *
import numpy as np

class MyDecisionNetwork(BayesNet):
    """An abstract class for a decision network as a wrapper for a BayesNet.
    Represents an agent's current state, its possible actions, reachable states
    and utilities of those states."""

    def __init__(self, result_node, infer, bn):
        """action: a single action node
        infer: the preferred method to carry out inference on the given BayesNet"""
        super(MyDecisionNetwork, self).__init__(bn)
        self.result_node = result_node
        self.infer = infer

    def best_action(self):
        """Return the best action in the network"""
        #return self.sprimenode
        raise NotImplementedError

    def get_utility(self, result_node):
        """Return the utility for a particular state"""
        #raise NotImplementedError
        return 0.0

    def get_expected_utility(self, result_node, action_and_evidence, evidence):
        """Compute the expected utility given an action and evidence"""

        eu = 0.0
        P_result_node = self.infer(result_node, action_and_evidence, self).prob
        for result_node, _ in result_node.items():
            eu += P_result_node[result_node] * self.get_utility(result_node)

        return eu



# todo define util func
# todo VOI ?
# 


def my_utility_function(state):
    # first map T/F encoding into (note we do this rather naively to be very clear)
    monetary_value = 0

    if(  state['Node1']==False and state['Node2']==False):
        monetary_value = 0.0
    elif(state['Node1']==False and state['Node2']==True):
        monetary_value = 5000.0
    elif(state['Node1']==True  and state['Node2']==False):
        monetary_value = 400.0
    elif(state['Node1']==True  and state['Node2']==True):
        monetary_value = 0.0
    else:
        print('Error')

    # then map from money to utility
    R = 400.0
    U = -np.exp(-monetary_value / R)
    return U


def expected_utility_two(P_result_nodes__evidence, util_func, result_nodes):
    
    eu = 0.0    
    for node1_outcome in [True,False]:
        for node2_outcome in [True,False]:
            # Compute the P(Node1,Node2 | Evidence)
            P_Node1_Node2__Evidence = (P_result_nodes__evidence[result_nodes[0]])[node1_outcome] *  (P_result_nodes__evidence[result_nodes[1]])[node2_outcome]
            state = dict(Node1=node1_outcome,Node2=node2_outcome)
            U = util_func(state)      
            eu += P_Node1_Node2__Evidence * U     

    return eu

def conditionals(result_nodes,bn):
    # P(Node1 | Evidence)
    P_result_nodes = dict()
    for result_node in result_nodes:
        P_result_nodes[result_node] = (enumeration_ask(result_node, evidence, bn).prob)
    return(P_result_nodes)  


gamebn = BayesNet([    
    ('Action_bet'   , ''           , 0.5),  # 50% for action or not (doesn't matter)
    ('Win400'       , 'Action_bet' , {T: 0.0  , F: 1.0}), # i.e. if Action_bet=False I always get 100, otherwise there is no chance to get 100, i.e. Win400=False
    ('Win5000'       , 'Action_bet' , {T: 0.6  , F: 0.0}), # i.e. if Action_bet=False I NEVER get 400, otherwise there is 50% chance of getting 400
    ])

############################################
if __name__ == "__main__":
    #
    print(gamebn)
            
    #
    result_nodes = ['Win400', 'Win5000']
    
    # First compute, the conditional distrbution of the result nodes given the evidence  
    evidence = dict(Action_bet=True)
    P_Win400_Win5000__Bet = conditionals(result_nodes,gamebn)    
    eu_bet = expected_utility_two(P_Win400_Win5000__Bet, my_utility_function, result_nodes)  
    print(eu_bet)

    evidence = dict(Action_bet=False)
    P_Win400_Win5000__NotBet = conditionals(result_nodes,gamebn)
    eu_not_bet = expected_utility_two(P_Win400_Win5000__NotBet, my_utility_function, result_nodes)  
    print(eu_not_bet)


    print(eu)